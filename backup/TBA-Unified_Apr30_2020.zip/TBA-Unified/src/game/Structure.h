#pragma once

#include <vector>

typedef std::vector<std::vector<int>> structure;

extern structure house;
extern structure bighouse;
extern structure bunker;
extern structure ruins;