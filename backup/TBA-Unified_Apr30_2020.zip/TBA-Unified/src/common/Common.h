#pragma once
#include "Game.h"

#define CONV_DEGREES (3.141592653589793238463/180.0)
#define CONV_RADIANS (180.0/3.141592653589793238463)

extern Game* TBAGame;