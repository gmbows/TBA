#pragma once

#include "Command.h"

#include <vector>
#include <string>


	//===========
	//FUNCTION LIST
	//===========

	//Clear
	std::string clearFunc(Command* command, const std::vector<std::string> &);

	//Inventory
	std::string inventoryFunc(Command* command, const std::vector<std::string> &);

	//Move
	std::string moveFunc(Command* command, const std::vector<std::string> &);
	bool moveEC(Command* command, const std::vector<std::string>&);

	//Pause
	std::string pauseFunc(Command*, const std::vector<std::string>&);

	//Stop
	std::string stopFunc(Command*, const std::vector<std::string>&);

	//Help
	std::string helpFunc(Command*, const std::vector<std::string>&);