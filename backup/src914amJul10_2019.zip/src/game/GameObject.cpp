#include "GameObject.h"
#include "../common/Common.h"
//Blank file for inclusion purposes

GameObject::GameObject() {
	TBAGame->gameObjects.push_back(this);
}