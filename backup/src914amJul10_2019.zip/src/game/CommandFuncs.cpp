#include "CommandFuncs.h"
#include "../common/Common.h"
#include "Command.h"

#include "World.h"

#include <vector>
#include <string>

#include <map>
#include <tuple>

std::map<std::string,std::pair<std::string,std::tuple<int,int>>> dirMap = {

	{"north",{"North",std::make_tuple(0,1)}},
	{"south",{"South",std::make_tuple(0,-1)}},
	{"east",{"East",std::make_tuple(1,0)}},
	{"west",{"West",std::make_tuple(-1,0)}},
	{"up",{"North",std::make_tuple(0,1)}},
	{"down",{"South",std::make_tuple(0,-1)}},
	{"right",{"East",std::make_tuple(1,0)}},
	{"left",{"West",std::make_tuple(-1,0)}},
	{"n",{"North",std::make_tuple(0,1)}},
	{"s",{"South",std::make_tuple(0,-1)}},
	{"e",{"East",std::make_tuple(1,0)}},
	{"w",{"West",std::make_tuple(-1,0)}},
	{"northwest",{"Northwest",std::make_tuple(-1,1)}},
	{"southwest",{"Southwest",std::make_tuple(-1,-1)}},
	{"northeast",{"Northeast",std::make_tuple(1,1)}},
	{"southeast",{"Southeast",std::make_tuple(1,-1)}},
	{"nw",{"Northwest",std::make_tuple(-1,1)}},
	{"sw",{"Southwest",std::make_tuple(-1,-1)}},
	{"ne",{"Northeast",std::make_tuple(1,1)}},
	{"se",{"Southeast",std::make_tuple(1,-1)}},

};

//Clear
std::string clearFunc(Command* command,const std::vector<std::string>& args) {
	TBAGame->gameWindow->textScreen->content.clear();
	return "";
}

//Inventory
std::string inventoryFunc(Command* command,const std::vector<std::string>& args) {
	return TBAGame->playerChar->inventory->toString();
}

//Move + EC
std::string moveFunc(Command* command, const std::vector<std::string> &args) {

	TBAGame->playerChar->autoMoveDirection = std::get<1>(dirMap.at(args.at(0)));
	TBAGame->playerChar->automove = true;
	return "\nMoving "+command->aux;
}
bool moveEC(Command* command, const std::vector<std::string>& args) {

	if(dirMap.find(args.at(0)) == dirMap.end()) {
		command->error = "Invalid direction";
		return false;
	}
	command->aux = std::get<0>(dirMap.at(args.at(0)));
	return true;

}

//Pause
std::string pauseFunc(Command* command, const std::vector<std::string> &args) {
	
	TBAGame->togglePause();
	return (TBAGame->paused)? "\nPaused" : "\nUnpaused";

}

//Stop
std::string stopFunc(Command* command, const std::vector<std::string> &args) {
	
	TBAGame->playerChar->automove = false;
	TBAGame->playerChar->direction = std::make_tuple(0,0);
	return "\nStopped moving";

}

//Help
std::string helpFunc(Command*, const std::vector<std::string>&) {

	return "\n"+join('\n',TBAGame->commandStrings);

}

