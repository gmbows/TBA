#pragma once

#include <vector>
#include <string>

#include "Item.h"
#include <ctime>

class Item {

	public:
		int id;
		
		std::string name;
		int weight;
		int size;
		time_t created;

	Item(int);

	std::string getName();

};