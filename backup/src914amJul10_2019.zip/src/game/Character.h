#pragma once

#include <SDL2/SDL.h>

struct Tile;

#include "../common/Tile.h"
#include "Inventory.h"
#include "GameObject.h"

#include <string>
#include <tuple>

class Character: public GameObject {

	public:
		float x,y;
		bool isPlayer;
		Inventory* inventory;
		std::string name;
		Tile* location = nullptr;
		int displayID;

		//Current movespeed per tick (dx,dy)
		float velocityX = 0;
		float velocityY = 0;
		int maxMoveSpeed;
		float traction;

		void setLocation(float,float);
		void move(std::tuple<int,int>);

		//Set move location to correct tile if target tile is occupied
		bool resolveMove(float&, float&);

		//Queued direction to be attempted next update
		std::tuple<int,int> direction;

		//Automove override when no keys are being pressed
		bool automove;
		std::tuple<int,int> autoMoveDirection;

		Character(bool,int,const std::string&,float=0,float=0);

		void update();

		virtual void cleanup();

		virtual inline std::string getName() {return this->name;}

		~Character() {
			debug("DELETED "+this->name);
		}

};