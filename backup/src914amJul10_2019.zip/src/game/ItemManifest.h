#include <vector>
#include <string>
#include <map>
#include <tuple>

typedef std::tuple<std::string,int,int> itemTraits;

std::map<int,itemTraits> itemManifest = {

	{0,std::make_tuple("Apple",1,4)},
	{1,std::make_tuple("Iron Ore",3,3)},
	{2,std::make_tuple("Rusted Longsword",3,3)},
	{3,std::make_tuple("Glass vial (empty)",3,3)},

};
