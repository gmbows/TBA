#pragma once
#include "../tools/StringFuncs.h"

#include <string>

class GameObject {

	public:

		std::string name;

		//Update function to be overridden for each object type
		virtual void update() {}
		virtual void cleanup(){}

		virtual std::string getName() {return "generic";}

		GameObject();

		~GameObject() {}

};