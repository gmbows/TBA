#include "Item.h"
#include "ItemManifest.h"
#include "../tools/StringFuncs.h"

#include <map>
#include <tuple>
#include <ctime>

Item::Item(int _id): id(_id) {

	if(itemManifest.find(id) == itemManifest.end()) {
		debug("ERROR: Adding invalid item with id "+std::to_string(id)+", using invalid item");
	}

	itemTraits itemInfo = itemManifest.at(id);

	this->name = std::get<0>(itemInfo);
	this->weight = std::get<1>(itemInfo);
	this->size = std::get<2>(itemInfo);

	this->created = std::time(nullptr);

}

std::string Item::getName() {
	//For advanced item types with names that may be different than default
	return this->name;
}