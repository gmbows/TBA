#include "Character.h"
#include "../common/Common.h"
#include "../tools/StringFuncs.h"
#include "GameObject.h"
#include "Inventory.h"

#include <tuple>
#include <random>

Character::Character(bool player, int capacity, const std::string& _name, float x,float y): x(x), y(y), isPlayer(player), name(_name), GameObject()  {

	this->location = TBAGame->gameWorld->getTileAt(x,y);
	if(player) {
		TBAGame->playerChar = this;
		this->maxMoveSpeed = 10; 
		this->displayID=3;
		this->traction = 1;
	} else {
		//Random movespeeds
		this->maxMoveSpeed = 10+((rand()%11)-5); //10+-5
		this->displayID=-1;
		this->traction = 1;
	}
	this->inventory = new Inventory(capacity);
	setLocation(x,y);
}

void Character::cleanup() {
	this->location->occupied = false;
	this->location->occupier = nullptr;
	this->location = nullptr;
	delete this->inventory;
	if(this->isPlayer) {
		new Character(true,160,"Generic",0,0);
	}
	delete this;
}

bool Character::resolveMove(float &newX, float &newY) {

	bool changed = false;


	//If movement on Y axis results in occupation conflict
	//Set Y movement to 0
	if(TBAGame->gameWorld->getTileAt(this->x,newY)->occupied or !TBAGame->gameWorld->locationIsValid(this->x,newY)) {
		if(TBAGame->gameWorld->getTileAt(this->x,newY) != this->location) {
			newY = this->y;
			changed = true;
		}
	}
	//If movement on X axis results in occupation conflict
	//Set X movement to 0
	if(TBAGame->gameWorld->getTileAt(newX,this->y)->occupied or !TBAGame->gameWorld->locationIsValid(newX,this->y)) {
		if(TBAGame->gameWorld->getTileAt(newX,this->y) != this->location) {
			newX = this->x;
			changed = true;
		}
	}

	return changed;

}

void Character::setLocation(float newX,float newY) {

	this->location->occupied = false;
	this->location->occupier = nullptr;

	this->x = newX;
	this->y = newY;

	this->location = TBAGame->gameWorld->getTileAt(this->x,this->y);
	this->location->occupyWith(this);

}

void Character::move(std::tuple<int,int> direction) {

	//Add new acceleration into character velocity
	this->velocityX += this->traction*std::get<0>(direction);
	this->velocityY += this->traction*std::get<1>(direction);

	this->velocityX = std::min((float)this->maxMoveSpeed,std::max((float)-this->maxMoveSpeed,this->velocityX));
	this->velocityY = std::min((float)this->maxMoveSpeed,std::max((float)-this->maxMoveSpeed,this->velocityY));

	//Max movespeed is never reached because velocity lost to tile roughness exceeds 1 AKA traction*X movement
	//debug(std::fabs(velocityX - velocityX*(1-(this->location->roughness))) >= 1);

	this->velocityX *= 1-(this->location->roughness);
	this->velocityY *= 1-(this->location->roughness);

	float newX = this->x+(this->velocityX * TBAGame->moveSpeedScale);
	float newY = this->y+(-this->velocityY * TBAGame->moveSpeedScale);

	//If character is trying to move into a new space
	if(TBAGame->gameWorld->getTileAt(newX,newY) != this->location) {
		//If new space is occupied
		if(TBAGame->gameWorld->getTileAt(newX,newY)->occupied or !TBAGame->gameWorld->locationIsValid(newX,newY)) {
			if(!this->resolveMove(newX,newY)) {
				//If move cannot be resolved to free space, cancel movement
				return;
			}
		}
	}

	this->setLocation(newX,newY);

	this->velocityX = (std::fabs(this->velocityX) < .01)? 0 : this->velocityX;
	this->velocityY = (std::fabs(this->velocityY) < .01)? 0 : this->velocityY;

}

void Character::update() {

	//NPC behavior system goes here
	if(!this->isPlayer) {
		int x = (this->x > TBAGame->playerChar->x)? -1 : 1;
		int y = (this->y > TBAGame->playerChar->y)? 1 : -1;
		this->direction = std::make_tuple(x,y);
	} else {
		if(this->automove) {
			this->direction = autoMoveDirection;
		}
	}
	this->move(this->direction);
}