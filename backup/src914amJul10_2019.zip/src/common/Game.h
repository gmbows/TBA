#pragma once

#include "../ui/Window.h"
#include "../tools/Log.h"

#include "../game/GameObject.h"
#include "../game/World.h"
#include "../game/Character.h"
#include "../game/Command.h"

#include <vector>
#include <string>

struct Game {

	bool gameRunning;
	bool paused = false;

	Window *gameWindow;
	Log *gameLog;

	World* gameWorld;
	Character* playerChar;

	//Global movespeed scale to translate from int movespeeds to floats
	float moveSpeedScale = .001;

	std::vector<GameObject*> gameObjects;


	//Update logic
	Uint32 currentTime = SDL_GetTicks();

	Uint32 lastGraphicsUpdate;
	Uint32 lastLogicUpdate;
	int elapsed;
	int timeToNextLogicUpdate;
	int timeToNextGraphicsUpdate;


	//Amount of times game game window updates per second
	int graphicsTickRate = 144;

	//Amount of times game OBJECTS (NPC's, general game state) update per second
	int logicTickRate = 100;

	int logicTicks;
	int graphicsTicks;

	std::vector<Command*> commandList;
	std::vector<std::string> commandStrings;	

	Game() {}

	void setupUI();
	void setupGame();

	bool togglePause();

	void updateGameObjects();
	void input();
	void update();

};