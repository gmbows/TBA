#pragma once

class Character;

#include "../game/Character.h"

#include <iostream>
#include <SDL2/SDL.h>
#include <random>
#include <ctime>
#include <map>
#include <vector>

struct Tile {
	std::vector<int> randomizedTextures = {-1,0};
	
	int id;
	int rotation;
	int x,y;
	SDL_RendererFlip flip;

	bool occupied;
	Character* occupier;

	//How fast character speed decays
	float roughness;
	
	Tile(int,int,int);

	~Tile() {}

	void occupyWith(Character*);

};