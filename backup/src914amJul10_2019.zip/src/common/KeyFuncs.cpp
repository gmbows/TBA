#include "KeyFuncs.h"

#include "../common/Common.h"
#include "../tools/StringFuncs.h"
#include "../game/Input.h"

#include <tuple>

bool moving = false;
int activeScreen = 1;
int lastMove[2];


void processKeystroke(int keycode) {
	if(moving) {
		switch(keycode) {
			case 114:
				resetScreen(activeScreen);
				moving = false;
				return;
			case 82: 
				resetAllScreens();
				moving = false;
				return;
		}
		
	}
	char c = keycode;
	TBAGame->gameWindow->textScreen->commandAppend(c);
}

//COMMAND

void sendCommand() {
	TBAGame->gameWindow->textScreen->sendCommand();
}

void swapCommand(int i) {
	TBAGame->gameWindow->textScreen->swapCommand(i);
}

void delChar() {
	//Pop back removes last entry in data structure
	TBAGame->gameWindow->textScreen->deleteLastCharacter();
}

void autocomplete() {
	if(autocomplete(TBAGame->gameWindow->textScreen->command,TBAGame->commandStrings)) {
		TBAGame->gameWindow->textScreen->commandAppend(' ');
	}
}

void commandAppend(char c) {
	//TBAGame->gameWindow->textScreen->commandAppend(c);
}

void pause() {
	
	TBAGame->togglePause();

}

//SCREEN

void click(SDL_MouseButtonEvent& event) {

	for(int i=TBAGame->gameWindow->screenVector.size()-1;i>=0;i--) {
		if(TBAGame->gameWindow->screenVector.at(i)->enclose(event.x,event.y)) {
			moving=true;
			activeScreen = TBAGame->gameWindow->screenVector.size()-1;
			TBAGame->gameWindow->bringToFront(TBAGame->gameWindow->screenVector.at(i));
			lastMove[0] = event.x;
			lastMove[1] = event.y;
			break;
		}
	}
}

void release() {
	moving = false;

}

void move(SDL_Event& event) {

	if(moving) {
		TBAGame->gameWindow->screenVector.at(activeScreen)->x += event.motion.x-lastMove[0];
		TBAGame->gameWindow->screenVector.at(activeScreen)->y += event.motion.y-lastMove[1];
	}
	lastMove[0] = event.motion.x;
	lastMove[1] = event.motion.y;
}

int getTopScreen(int x,int y) {
	int topScreenID;
	for(int i=0;i<TBAGame->gameWindow->screenVector.size();i++) {
		if(TBAGame->gameWindow->screenVector.at(i)->enclose(x,y)) {
			topScreenID = i;
		}
	}
	return topScreenID;
}

void shiftContentWindow(int i) {

	//Get the topmost screen that the mouse is hovering over and scroll it
	TBAGame->gameWindow->screenVector.at(getTopScreen(lastMove[0],lastMove[1]))->shiftContentWindow(i);

}

void addContent(const std::string& s) {
	TBAGame->gameWindow->textScreen->addContent(s);
}

void resetScreen(int screenPriority) {
	TBAGame->gameWindow->screenVector.at(screenPriority)->x = TBAGame->gameWindow->screenVector.at(screenPriority)->defaultX;
	TBAGame->gameWindow->screenVector.at(screenPriority)->y = TBAGame->gameWindow->screenVector.at(screenPriority)->defaultY;
}

void resetAllScreens() {
	int screenCount = TBAGame->gameWindow->screenVector.size();
	for(int i=0;i<screenCount;i++) {
		resetScreen(i);
	}
}

//PLAYER MOVEMENT

void move(bool m_up,bool m_down,bool m_left, bool m_right) {

		std::tuple<int,int> Qdirection;

		int x = 0;
		int y = 0;

		if(m_up)	{
			y += 1;
		}
		if(m_down) 	{
			y -= 1;
		}
		if(m_left) 	{
			x -= 1;
		}
		if(m_right) {
			x =+ 1;
		}

	Qdirection = std::make_tuple(x,y);

	TBAGame->playerChar->direction = Qdirection;
	TBAGame->playerChar->automove = false;

}

//MISC

void debugKey() {
	//Delete oldest object
	TBAGame->gameObjects.at(0)->cleanup();
	TBAGame->gameObjects.erase(TBAGame->gameObjects.begin());
	TBAGame->gameObjects.shrink_to_fit();
}