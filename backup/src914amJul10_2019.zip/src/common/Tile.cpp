#include "Tile.h"

#include "../tools/StringFuncs.h"
#include "../game/Character.h"

#include <iostream>
#include <SDL2/SDL.h>
#include <random>
#include <ctime>
#include <vector>
#include <map>

Tile::Tile(int tid, int _x, int _y): id(tid), x(_x), y(_y) {

	this->occupied = false;

	this->roughness = .04;

	if(contains(randomizedTextures,tid)) {
		this->rotation = 90*(rand()%4);
		switch(rand()%3) {
			case 0:
				this->flip = SDL_FLIP_NONE;
				break;
			case 1:
				this->flip = SDL_FLIP_HORIZONTAL;
				break;
			case 2:
				this->flip = SDL_FLIP_VERTICAL;
				break;
		}
	} else {
		this->roughness = .13;
		this->rotation = 0;
		this->flip = SDL_FLIP_NONE;
		return;
	}
}

void Tile::occupyWith(Character* c) {
	this->occupied = true;
	this->occupier = c;
}