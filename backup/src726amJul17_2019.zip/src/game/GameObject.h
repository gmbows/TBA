#pragma once
#include "../tools/StringFuncs.h"

#include <string>
#include <utility>
#include <tuple>

enum objType {
	OBJ_GENERIC,
	OBJ_CHARACTER,
	OBJ_BLOCK,
	UI_FLOATINGTEXT
};

class GameObject {

	public:

		int objectID;
		objType objectType = OBJ_GENERIC;

		//Update function to be overridden for each object type
		virtual void update() {}
		virtual void cleanup(){}

		virtual std::string getName() {return "NAME_UNSET";}
		virtual std::string getInfo() {return "INFO_UNSET";}
		virtual std::tuple<float,float> getLocation() {return std::make_tuple(-1,-1);}

		GameObject(objType);

		~GameObject() {}

};