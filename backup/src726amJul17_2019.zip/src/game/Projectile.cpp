#include "Projectile.h"
#include "GameObject.h"

Projectile::Projectile(std::tuple<float,float> _location,float _ang,float _velocity): location(_location), ang(_ang), velocity(_velocity), GameObject() {

}