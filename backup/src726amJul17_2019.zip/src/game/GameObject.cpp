#include "GameObject.h"
#include "../common/Common.h"
//Blank file for inclusion purposes

GameObject::GameObject(objType obj): objectType(obj) {
	this->objectID = ++TBAGame->objectTotal;

	switch(this->objectType) {
		case OBJ_GENERIC:
			debug("DEBUG: CREATING GENERIC OBJECT");
		case OBJ_BLOCK:
		case OBJ_CHARACTER:
			TBAGame->gameObjects.push_back(this);
			break;
		case UI_FLOATINGTEXT:
			TBAGame->gameUIObjects.push_back(this);
			break;
	}
	
}