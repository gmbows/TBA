#pragma once

#include "GameObject.h"
class Projectile: public GameObject {
	float x,y;
	float angle;
	float velocity;

	Projectile(std::tuple<float,float>,float,float);

	void update() {
		this->x += velocity*cos(ang);
		this->y += velocity*sin(ang);
	}
};