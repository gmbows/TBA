#pragma once

class Character;

#include "../game/Character.h"
#include "../game/Block.h"

#include <iostream>
#include <SDL2/SDL.h>
#include <random>
#include <ctime>
#include <map>
#include <vector>

extern std::map<int,std::tuple<float,bool,bool>> tileMap;

struct Tile {
	
	int id;
	int rotation;
	int x,y;
	SDL_RendererFlip flip;

	bool inline isOccupied() {return this->occupiers.size() > 0;}
	std::vector<Character*> occupiers;

	std::vector<Block*> blocks;
	bool inline hasBlocks() {return this->blocks.size() > 0;}
	void addBlock(int);
	void addBlock(Block*);
	int getRotation();
	SDL_RendererFlip getFlip();
	SDL_Texture* getBlockTexture();
	bool isPassable();
	void evict(Character*);
	Character* getNextOccupant(Character*);

	int inline getDisplayID() {return ((this->blocks.size() == 0)? this->id : this->blocks.at(this->blocks.size()-1)->id); }

	bool passable = true;
	bool invalid = false;
	bool randomized = false;

	//How fast character speed decays
	float roughness;
	
	Tile(int,int,int);
	

	~Tile() {}

	void occupyWith(Character*);

};