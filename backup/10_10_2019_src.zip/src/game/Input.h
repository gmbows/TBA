#pragma once
#include <string>

std::string processCommand(const std::string&);