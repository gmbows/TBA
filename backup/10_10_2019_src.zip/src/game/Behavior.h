#pragma once

#include <map>

enum statusIndicator: int;
enum attackStatus: int;

extern std::map<statusIndicator,const std::string> statusMap;