#pragma once

#include <vector>

typedef std::vector<std::vector<int>> structure;

extern structure house;