#include "Common.h"
#include "Game.h"

//Primary game object
Game* TBAGame = new Game();