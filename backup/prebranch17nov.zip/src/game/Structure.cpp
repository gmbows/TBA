#include "Structure.h"

structure house = 
{

{1,1,1,1,1},
{1,0,0,0,1},
{1,0,0,0,1},
{1,0,0,0,1},
{1,1,0,1,1},

};