#pragma once
#include "Game.h"

extern Game* TBAGame;