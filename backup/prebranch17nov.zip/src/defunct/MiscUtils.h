#pragma once

#include "GameObject.h"
#include "Container.h"
#include "Character.h"
#include "Inventory.h"

Inventory* GameObject::getInventory();